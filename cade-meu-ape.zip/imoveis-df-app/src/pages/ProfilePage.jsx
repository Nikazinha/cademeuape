import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';
import PropertyCard from '../components/PropertyCard';
import { useAuth } from '../contexts/AuthContext';
import { FaUser, FaHeart, FaSignOutAlt, FaHistory } from 'react-icons/fa';
import { getPropertyDetails } from '../services/propertyService';

const ProfilePage = () => {
  const { currentUser, logout, getFavorites } = useAuth();
  const [activeTab, setActiveTab] = useState('profile');
  const [favoriteProperties, setFavoriteProperties] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  
  const navigate = useNavigate();
  
  // Redirecionar se não estiver logado
  useEffect(() => {
    if (!currentUser) {
      navigate('/entrar');
    }
  }, [currentUser, navigate]);
  
  // Carregar imóveis favoritos
  useEffect(() => {
    const loadFavorites = async () => {
      if (currentUser) {
        try {
          setLoading(true);
          setError('');
          
          const favoriteIds = await getFavorites();
          
          // Buscar detalhes de cada imóvel favorito
          const propertiesPromises = favoriteIds.map(id => getPropertyDetails(id));
          const properties = await Promise.all(propertiesPromises);
          
          // Filtrar possíveis nulos (imóveis que não existem mais)
          setFavoriteProperties(properties.filter(Boolean));
        } catch (error) {
          console.error('Erro ao carregar favoritos:', error);
          setError('Não foi possível carregar seus imóveis favoritos');
        } finally {
          setLoading(false);
        }
      }
    };
    
    loadFavorites();
  }, [currentUser, getFavorites]);
  
  // Função para fazer logout
  const handleLogout = () => {
    logout();
    navigate('/');
  };
  
  // Se não estiver logado, não renderizar nada (será redirecionado)
  if (!currentUser) {
    return null;
  }
  
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow bg-gray-100 py-8">
        <div className="container-custom">
          <h1 className="text-2xl font-bold text-gray-800 mb-6">
            Minha Conta
          </h1>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {/* Sidebar */}
            <div className="md:col-span-1">
              <div className="bg-white rounded-lg shadow-md p-4">
                <div className="flex flex-col items-center mb-6">
                  <div className="w-20 h-20 rounded-full bg-primary text-white flex items-center justify-center text-3xl mb-2">
                    {currentUser.name.charAt(0).toUpperCase()}
                  </div>
                  <h2 className="text-lg font-semibold">{currentUser.name}</h2>
                  <p className="text-gray-600 text-sm">{currentUser.email}</p>
                </div>
                
                <nav>
                  <ul className="space-y-2">
                    <li>
                      <button
                        onClick={() => setActiveTab('profile')}
                        className={`w-full text-left px-4 py-2 rounded-md flex items-center ${
                          activeTab === 'profile' 
                            ? 'bg-primary text-white' 
                            : 'text-gray-700 hover:bg-gray-100'
                        }`}
                      >
                        <FaUser className="mr-2" />
                        Perfil
                      </button>
                    </li>
                    <li>
                      <button
                        onClick={() => setActiveTab('favorites')}
                        className={`w-full text-left px-4 py-2 rounded-md flex items-center ${
                          activeTab === 'favorites' 
                            ? 'bg-primary text-white' 
                            : 'text-gray-700 hover:bg-gray-100'
                        }`}
                      >
                        <FaHeart className="mr-2" />
                        Favoritos
                      </button>
                    </li>
                    <li>
                      <button
                        onClick={() => setActiveTab('history')}
                        className={`w-full text-left px-4 py-2 rounded-md flex items-center ${
                          activeTab === 'history' 
                            ? 'bg-primary text-white' 
                            : 'text-gray-700 hover:bg-gray-100'
                        }`}
                      >
                        <FaHistory className="mr-2" />
                        Histórico
                      </button>
                    </li>
                    <li>
                      <button
                        onClick={handleLogout}
                        className="w-full text-left px-4 py-2 rounded-md text-red-600 hover:bg-red-50 flex items-center"
                      >
                        <FaSignOutAlt className="mr-2" />
                        Sair
                      </button>
                    </li>
                  </ul>
                </nav>
              </div>
            </div>
            
            {/* Conteúdo principal */}
            <div className="md:col-span-3">
              <div className="bg-white rounded-lg shadow-md p-6">
                {/* Perfil */}
                {activeTab === 'profile' && (
                  <div>
                    <h2 className="text-xl font-semibold mb-4">Informações Pessoais</h2>
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Nome completo
                        </label>
                        <input
                          type="text"
                          value={currentUser.name}
                          readOnly
                          className="w-full p-2 border border-gray-300 rounded-md bg-gray-50"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          E-mail
                        </label>
                        <input
                          type="email"
                          value={currentUser.email}
                          readOnly
                          className="w-full p-2 border border-gray-300 rounded-md bg-gray-50"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Data de cadastro
                        </label>
                        <input
                          type="text"
                          value={new Date(currentUser.createdAt).toLocaleDateString('pt-BR')}
                          readOnly
                          className="w-full p-2 border border-gray-300 rounded-md bg-gray-50"
                        />
                      </div>
                    </div>
                    
                    <div className="mt-6">
                      <h3 className="text-lg font-semibold mb-2">Alterar senha</h3>
                      <p className="text-gray-600 mb-4">
                        Para alterar sua senha, preencha os campos abaixo:
                      </p>
                      <div className="space-y-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Senha atual
                          </label>
                          <input
                            type="password"
                            className="w-full p-2 border border-gray-300 rounded-md"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Nova senha
                          </label>
                          <input
                            type="password"
                            className="w-full p-2 border border-gray-300 rounded-md"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Confirmar nova senha
                          </label>
                          <input
                            type="password"
                            className="w-full p-2 border border-gray-300 rounded-md"
                          />
                        </div>
                        <button className="bg-primary hover:bg-primary-dark text-white font-medium py-2 px-4 rounded-md transition-colors">
                          Alterar Senha
                        </button>
                      </div>
                    </div>
                  </div>
                )}
                
                {/* Favoritos */}
                {activeTab === 'favorites' && (
                  <div>
                    <h2 className="text-xl font-semibold mb-4">Imóveis Favoritos</h2>
                    
                    {loading ? (
                      <div className="text-center py-8">
                        <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-primary mb-4"></div>
                        <p className="text-gray-600">Carregando seus imóveis favoritos...</p>
                      </div>
                    ) : error ? (
                      <div className="text-center py-8 text-red-600">
                        <p>{error}</p>
                      </div>
                    ) : favoriteProperties.length === 0 ? (
                      <div className="text-center py-8">
                        <p className="text-gray-600">Você ainda não adicionou nenhum imóvel aos favoritos.</p>
                        <Link 
                          to="/buscar"
                          className="mt-4 inline-block bg-primary hover:bg-primary-dark text-white font-medium py-2 px-4 rounded-md transition-colors"
                        >
                          Buscar Imóveis
                        </Link>
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {favoriteProperties.map(property => (
                          <PropertyCard key={property.id} property={property} />
                        ))}
                      </div>
                    )}
                  </div>
                )}
                
                {/* Histórico */}
                {activeTab === 'history' && (
                  <div>
                    <h2 className="text-xl font-semibold mb-4">Histórico de Buscas</h2>
                    
                    <div className="text-center py-8">
                      <p className="text-gray-600">Histórico de buscas em desenvolvimento.</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default ProfilePage;
