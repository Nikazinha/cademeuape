import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';
import Hero from '../components/Hero';
import PropertyCard from '../components/PropertyCard';
import { FaChartBar, FaBuilding, FaSearch, FaArrowRight } from 'react-icons/fa';
import { usePropertySearch } from '../services/propertyService';

const HomePage = () => {
  const { properties, loading, error, searchProperties } = usePropertySearch();
  const [featuredProperties, setFeaturedProperties] = useState([]);
  
  // Buscar imóveis em destaque ao carregar a página
  useEffect(() => {
    const fetchFeaturedProperties = async () => {
      // Buscar todos os imóveis e selecionar alguns para destaque
      await searchProperties();
    };
    
    fetchFeaturedProperties();
  }, []);
  
  // Selecionar imóveis em destaque quando os dados forem carregados
  useEffect(() => {
    if (properties.length > 0) {
      // Selecionar até 6 imóveis para destaque (aleatoriamente ou por algum critério)
      const featured = properties.slice(0, 6);
      setFeaturedProperties(featured);
    }
  }, [properties]);
  
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow">
        {/* Hero section com busca rápida */}
        <Hero />
        
        {/* Imóveis em destaque */}
        <section className="py-12 bg-white">
          <div className="container-custom">
            <div className="flex justify-between items-center mb-8">
              <h2 className="text-2xl font-bold text-gray-800">Imóveis em Destaque</h2>
              <Link to="/buscar" className="text-primary hover:text-primary-dark flex items-center">
                Ver todos <FaArrowRight className="ml-1" />
              </Link>
            </div>
            
            {loading ? (
              <div className="text-center py-8">
                <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-primary mb-4"></div>
                <p className="text-gray-600">Carregando imóveis em destaque...</p>
              </div>
            ) : error ? (
              <div className="text-center py-8 text-red-600">
                <p>{error}</p>
                <button 
                  onClick={() => searchProperties()}
                  className="mt-4 px-4 py-2 bg-primary text-white rounded-md hover:bg-primary-dark"
                >
                  Tentar novamente
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {featuredProperties.map(property => (
                  <PropertyCard key={property.id} property={property} />
                ))}
                
                {featuredProperties.length === 0 && (
                  <div className="col-span-3 text-center py-8">
                    <p className="text-gray-600">Nenhum imóvel em destaque no momento.</p>
                    <Link 
                      to="/buscar"
                      className="mt-4 inline-block px-4 py-2 bg-primary text-white rounded-md hover:bg-primary-dark"
                    >
                      Buscar Imóveis
                    </Link>
                  </div>
                )}
              </div>
            )}
          </div>
        </section>
        
        {/* Seção de recursos */}
        <section className="py-12 bg-gray-50">
          <div className="container-custom">
            <h2 className="text-2xl font-bold text-gray-800 text-center mb-12">Por que usar o ImóveisDF?</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-white p-6 rounded-lg shadow-md text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-primary/10 text-primary rounded-full mb-4">
                  <FaSearch className="text-2xl" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Busca Avançada</h3>
                <p className="text-gray-600">
                  Encontre o imóvel perfeito com nossos filtros avançados. Busque por localização, tamanho, 
                  número de quartos, garagem, permissão para pets e muito mais.
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-md text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-secondary/10 text-secondary rounded-full mb-4">
                  <FaBuilding className="text-2xl" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Compare Imóveis</h3>
                <p className="text-gray-600">
                  Compare diferentes imóveis lado a lado para tomar a melhor decisão. 
                  Analise preços, características e comodidades de forma simples e rápida.
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-md text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-green-100 text-green-600 rounded-full mb-4">
                  <FaChartBar className="text-2xl" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Análise de Mercado</h3>
                <p className="text-gray-600">
                  Acesse dados e estatísticas sobre o mercado imobiliário no DF. 
                  Conheça os preços médios por região e tome decisões informadas.
                </p>
              </div>
            </div>
            
            <div className="text-center mt-10">
              <Link 
                to="/buscar"
                className="px-6 py-3 bg-primary hover:bg-primary-dark text-white rounded-md transition-colors"
              >
                Começar a Buscar
              </Link>
            </div>
          </div>
        </section>
        
        {/* Seção de regiões populares */}
        <section className="py-12 bg-white">
          <div className="container-custom">
            <h2 className="text-2xl font-bold text-gray-800 text-center mb-8">Regiões Populares no DF</h2>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Link to="/buscar?location=Águas Claras" className="group">
                <div className="relative h-40 rounded-lg overflow-hidden">
                  <img 
                    src="https://images.unsplash.com/photo-1560185007-cde436f6a4d0?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80" 
                    alt="Águas Claras"
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
                  <h3 className="absolute bottom-3 left-3 text-white font-semibold">Águas Claras</h3>
                </div>
              </Link>
              
              <Link to="/buscar?location=Asa Norte" className="group">
                <div className="relative h-40 rounded-lg overflow-hidden">
                  <img 
                    src="https://images.unsplash.com/photo-1493809842364-78817add7ffb?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80" 
                    alt="Asa Norte"
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
                  <h3 className="absolute bottom-3 left-3 text-white font-semibold">Asa Norte</h3>
                </div>
              </Link>
              
              <Link to="/buscar?location=Sudoeste" className="group">
                <div className="relative h-40 rounded-lg overflow-hidden">
                  <img 
                    src="https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80" 
                    alt="Sudoeste"
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
                  <h3 className="absolute bottom-3 left-3 text-white font-semibold">Sudoeste</h3>
                </div>
              </Link>
              
              <Link to="/buscar?location=Lago Norte" className="group">
                <div className="relative h-40 rounded-lg overflow-hidden">
                  <img 
                    src="https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80" 
                    alt="Lago Norte"
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
                  <h3 className="absolute bottom-3 left-3 text-white font-semibold">Lago Norte</h3>
                </div>
              </Link>
            </div>
            
            <div className="text-center mt-8">
              <Link 
                to="/buscar"
                className="text-primary hover:text-primary-dark font-medium"
              >
                Ver todas as regiões
              </Link>
            </div>
          </div>
        </section>
        
        {/* Call to action */}
        <section className="py-16 bg-gradient-to-r from-primary to-primary-dark text-white">
          <div className="container-custom text-center">
            <h2 className="text-3xl font-bold mb-4">Encontre o Imóvel dos Seus Sonhos</h2>
            <p className="text-xl mb-8 max-w-2xl mx-auto">
              Milhares de opções de aluguel no Distrito Federal com os melhores filtros para sua busca.
            </p>
            <Link 
              to="/buscar"
              className="px-8 py-3 bg-white text-primary hover:bg-gray-100 rounded-md transition-colors font-medium"
            >
              Buscar Imóveis
            </Link>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default HomePage;
