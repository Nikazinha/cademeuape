import React from 'react';
import { Link } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { FaExclamationTriangle } from 'react-icons/fa';

const NotFoundPage = () => {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow bg-gray-100 py-12">
        <div className="container-custom">
          <div className="bg-white rounded-lg shadow-md p-8 text-center max-w-2xl mx-auto">
            <FaExclamationTriangle className="text-6xl text-secondary mx-auto mb-4" />
            <h1 className="text-3xl font-bold text-gray-800 mb-4">Página não encontrada</h1>
            <p className="text-gray-600 mb-6">
              A página que você está procurando não existe ou foi movida.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Link 
                to="/"
                className="px-6 py-3 bg-primary hover:bg-primary-dark text-white rounded-md transition-colors"
              >
                Voltar para a página inicial
              </Link>
              <Link 
                to="/buscar"
                className="px-6 py-3 bg-gray-200 hover:bg-gray-300 text-gray-800 rounded-md transition-colors"
              >
                Buscar imóveis
              </Link>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default NotFoundPage;
