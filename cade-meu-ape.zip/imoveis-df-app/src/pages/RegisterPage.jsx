import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';
import AuthForms from '../components/AuthForms';
import { useAuth } from '../contexts/AuthContext';

const RegisterPage = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  
  const { register } = useAuth();
  const navigate = useNavigate();
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      setError('');
      setLoading(true);
      
      if (password !== confirmPassword) {
        return setError('As senhas não coincidem');
      }
      
      const result = await register(name, email, password);
      
      if (result.success) {
        setSuccess(true);
        // Redirecionar após registro bem-sucedido
        setTimeout(() => {
          navigate('/');
        }, 1500);
      } else {
        setError(result.error);
      }
    } catch (error) {
      setError('Falha ao criar conta. Por favor, tente novamente.');
      console.error('Erro de registro:', error);
    } finally {
      setLoading(false);
    }
  };
  
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow bg-gray-100 py-12">
        <div className="container-custom">
          <div className="max-w-md mx-auto">
            <h1 className="text-2xl font-bold text-center text-gray-800 mb-6">
              Criar uma nova conta
            </h1>
            
            {error && (
              <div className="bg-red-100 text-red-700 p-3 rounded mb-4">
                {error}
              </div>
            )}
            
            {success && (
              <div className="bg-green-100 text-green-700 p-3 rounded mb-4">
                Conta criada com sucesso! Redirecionando...
              </div>
            )}
            
            <AuthForms formType="register" />
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default RegisterPage;
