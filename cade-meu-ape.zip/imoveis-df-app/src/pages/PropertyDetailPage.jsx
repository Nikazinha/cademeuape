import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';
import PropertyDetail from '../components/PropertyDetail';
import { getPropertyDetails } from '../services/propertyService';

const PropertyDetailPage = () => {
  // Obter o ID do imóvel da URL
  const { id } = useParams();
  
  // Estados para armazenar os dados do imóvel e o estado de carregamento
  const [property, setProperty] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  // Efeito para carregar os detalhes do imóvel
  useEffect(() => {
    const fetchPropertyDetails = async () => {
      try {
        setLoading(true);
        setError(null);
        
        const propertyData = await getPropertyDetails(id);
        
        if (propertyData) {
          setProperty(propertyData);
        } else {
          setError('Imóvel não encontrado');
        }
      } catch (error) {
        console.error('Erro ao carregar detalhes do imóvel:', error);
        setError('Ocorreu um erro ao carregar os detalhes do imóvel');
      } finally {
        setLoading(false);
      }
    };
    
    fetchPropertyDetails();
  }, [id]);
  
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow bg-gray-100 py-8">
        <div className="container-custom">
          {/* Breadcrumb */}
          <div className="mb-4">
            <nav className="text-sm">
              <ol className="list-none p-0 inline-flex">
                <li className="flex items-center">
                  <Link to="/" className="text-primary hover:text-primary-dark">Início</Link>
                  <span className="mx-2 text-gray-500">/</span>
                </li>
                <li className="flex items-center">
                  <Link to="/buscar" className="text-primary hover:text-primary-dark">Buscar</Link>
                  <span className="mx-2 text-gray-500">/</span>
                </li>
                <li className="text-gray-700">Detalhes do Imóvel</li>
              </ol>
            </nav>
          </div>
          
          {loading ? (
            <div className="bg-white rounded-lg shadow-md p-8 text-center">
              <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-primary mb-4"></div>
              <p className="text-gray-600">Carregando detalhes do imóvel...</p>
            </div>
          ) : error ? (
            <div className="bg-white rounded-lg shadow-md p-8 text-center">
              <p className="text-red-600 mb-4">{error}</p>
              <Link 
                to="/buscar"
                className="px-4 py-2 bg-primary text-white rounded-md hover:bg-primary-dark"
              >
                Voltar para a busca
              </Link>
            </div>
          ) : (
            <PropertyDetail property={property} />
          )}
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default PropertyDetailPage;
