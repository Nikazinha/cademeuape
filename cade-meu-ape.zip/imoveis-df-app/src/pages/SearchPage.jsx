import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FilterSidebar from '../components/FilterSidebar';
import SearchResults from '../components/SearchResults';
import PropertyCard from '../components/PropertyCard';
import { usePropertySearch } from '../services/propertyService';

const SearchPage = () => {
  // Estado para armazenar os filtros atuais
  const [filters, setFilters] = useState({});
  
  // Estado para controlar a visualização dos resultados (grid ou lista)
  const [viewMode, setViewMode] = useState('grid');
  
  // Estado para controlar a ordenação dos resultados
  const [sortOption, setSortOption] = useState('price_asc');
  
  // Hook personalizado para busca de imóveis
  const { properties, loading, error, totalResults, searchProperties } = usePropertySearch();
  
  // Obter parâmetros da URL
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  
  // Efeito para iniciar a busca com base nos parâmetros da URL
  useEffect(() => {
    const locationParam = queryParams.get('location') || '';
    
    // Configurar filtros iniciais com base nos parâmetros da URL
    const initialFilters = {
      location: locationParam,
    };
    
    setFilters(initialFilters);
    
    // Iniciar busca com os filtros iniciais
    searchProperties(initialFilters, sortOption);
  }, [location.search]);
  
  // Manipulador para aplicar filtros
  const handleApplyFilters = (newFilters) => {
    setFilters(newFilters);
    searchProperties(newFilters, sortOption);
  };
  
  // Efeito para reordenar os resultados quando a opção de ordenação muda
  useEffect(() => {
    if (properties.length > 0) {
      searchProperties(filters, sortOption);
    }
  }, [sortOption]);
  
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow bg-gray-100 py-8">
        <div className="container-custom">
          <h1 className="text-2xl font-bold text-gray-800 mb-6">
            Imóveis para Aluguel no DF
            {filters.location && <span> em {filters.location}</span>}
          </h1>
          
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            {/* Sidebar com filtros */}
            <div className="lg:col-span-1">
              <FilterSidebar onApplyFilters={handleApplyFilters} />
            </div>
            
            {/* Resultados da busca */}
            <div className="lg:col-span-3">
              {loading ? (
                <div className="bg-white rounded-lg shadow-md p-8 text-center">
                  <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-primary mb-4"></div>
                  <p className="text-gray-600">Buscando imóveis...</p>
                </div>
              ) : error ? (
                <div className="bg-white rounded-lg shadow-md p-8 text-center text-red-600">
                  <p>{error}</p>
                  <button 
                    onClick={() => searchProperties(filters, sortOption)}
                    className="mt-4 px-4 py-2 bg-primary text-white rounded-md hover:bg-primary-dark"
                  >
                    Tentar novamente
                  </button>
                </div>
              ) : (
                <div>
                  <SearchResults 
                    properties={properties}
                    viewMode={viewMode}
                    setViewMode={setViewMode}
                    sortOption={sortOption}
                    setSortOption={setSortOption}
                  />
                  
                  <div className={`mt-6 ${
                    viewMode === 'grid' 
                      ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6' 
                      : 'space-y-6'
                  }`}>
                    {properties.map(property => (
                      <PropertyCard key={property.id} property={property} />
                    ))}
                  </div>
                  
                  {properties.length === 0 && !loading && (
                    <div className="bg-white rounded-lg shadow-md p-8 text-center mt-6">
                      <p className="text-gray-600">Nenhum imóvel encontrado com os filtros selecionados.</p>
                      <p className="text-gray-500 mt-2">Tente ajustar seus filtros para ver mais resultados.</p>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default SearchPage;
