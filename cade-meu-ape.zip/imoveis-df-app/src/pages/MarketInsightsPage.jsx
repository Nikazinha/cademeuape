import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { FaChartBar, FaBuilding, FaMapMarkerAlt, FaMoneyBillWave, FaBed, FaBath } from 'react-icons/fa';
import { usePropertySearch } from '../services/propertyService';
import { Bar, Pie, Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  PointElement,
  LineElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';

// Registrar componentes do Chart.js
ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  PointElement,
  LineElement,
  ArcElement,
  Title,
  Tooltip,
  Legend
);

const MarketInsightsPage = () => {
  const { properties, loading, error, searchProperties } = usePropertySearch();
  const [activeTab, setActiveTab] = useState('price');
  const navigate = useNavigate();
  
  // Buscar todos os imóveis ao carregar a página
  useEffect(() => {
    searchProperties();
  }, []);
  
  // Função para calcular a média de preços por localização
  const calculatePriceByLocation = () => {
    if (!properties || properties.length === 0) return { labels: [], data: [] };
    
    const locationMap = new Map();
    
    properties.forEach(property => {
      // Extrair apenas o bairro/região do endereço
      const location = property.address.split(',')[0].trim();
      
      if (locationMap.has(location)) {
        locationMap.get(location).prices.push(property.price);
      } else {
        locationMap.set(location, { prices: [property.price] });
      }
    });
    
    // Calcular médias
    const locations = [];
    const averagePrices = [];
    
    locationMap.forEach((value, key) => {
      const sum = value.prices.reduce((acc, price) => acc + price, 0);
      const average = Math.round(sum / value.prices.length);
      
      locations.push(key);
      averagePrices.push(average);
    });
    
    // Ordenar por preço médio (decrescente)
    const combined = locations.map((location, i) => ({ location, price: averagePrices[i] }));
    combined.sort((a, b) => b.price - a.price);
    
    return {
      labels: combined.map(item => item.location),
      data: combined.map(item => item.price)
    };
  };
  
  // Função para calcular a distribuição de imóveis por número de quartos
  const calculateBedroomsDistribution = () => {
    if (!properties || properties.length === 0) return { labels: [], data: [] };
    
    const bedroomsMap = new Map();
    
    properties.forEach(property => {
      const bedrooms = property.bedrooms;
      
      if (bedroomsMap.has(bedrooms)) {
        bedroomsMap.set(bedrooms, bedroomsMap.get(bedrooms) + 1);
      } else {
        bedroomsMap.set(bedrooms, 1);
      }
    });
    
    // Ordenar por número de quartos
    const sortedEntries = [...bedroomsMap.entries()].sort((a, b) => a[0] - b[0]);
    
    return {
      labels: sortedEntries.map(entry => `${entry[0]} ${entry[0] === 1 ? 'quarto' : 'quartos'}`),
      data: sortedEntries.map(entry => entry[1])
    };
  };
  
  // Função para calcular a relação entre área e preço
  const calculateAreaPriceRelation = () => {
    if (!properties || properties.length === 0) return { areas: [], prices: [] };
    
    // Ordenar por área
    const sortedProperties = [...properties].sort((a, b) => a.area - b.area);
    
    return {
      areas: sortedProperties.map(property => property.area),
      prices: sortedProperties.map(property => property.price)
    };
  };
  
  // Função para calcular a distribuição de imóveis por faixa de preço
  const calculatePriceRangeDistribution = () => {
    if (!properties || properties.length === 0) return { labels: [], data: [] };
    
    const ranges = [
      { label: 'Até R$ 1.500', max: 1500, count: 0 },
      { label: 'R$ 1.501 - R$ 2.500', min: 1501, max: 2500, count: 0 },
      { label: 'R$ 2.501 - R$ 3.500', min: 2501, max: 3500, count: 0 },
      { label: 'R$ 3.501 - R$ 5.000', min: 3501, max: 5000, count: 0 },
      { label: 'Acima de R$ 5.000', min: 5001, count: 0 }
    ];
    
    properties.forEach(property => {
      const price = property.price;
      
      for (const range of ranges) {
        if (
          (range.min === undefined || price >= range.min) &&
          (range.max === undefined || price <= range.max)
        ) {
          range.count++;
          break;
        }
      }
    });
    
    return {
      labels: ranges.map(range => range.label),
      data: ranges.map(range => range.count)
    };
  };
  
  // Dados para os gráficos
  const priceByLocation = calculatePriceByLocation();
  const bedroomsDistribution = calculateBedroomsDistribution();
  const areaPriceRelation = calculateAreaPriceRelation();
  const priceRangeDistribution = calculatePriceRangeDistribution();
  
  // Configurações dos gráficos
  const barChartOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: true,
        text: 'Preço Médio por Localização',
      },
    },
  };
  
  const pieChartOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: true,
        text: 'Distribuição por Número de Quartos',
      },
    },
  };
  
  const scatterChartOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: true,
        text: 'Relação entre Área e Preço',
      },
    },
    scales: {
      x: {
        title: {
          display: true,
          text: 'Área (m²)',
        },
      },
      y: {
        title: {
          display: true,
          text: 'Preço (R$)',
        },
      },
    },
  };
  
  const priceRangeOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: true,
        text: 'Distribuição por Faixa de Preço',
      },
    },
  };
  
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow bg-gray-100 py-8">
        <div className="container-custom">
          <h1 className="text-2xl font-bold text-gray-800 mb-6 flex items-center">
            <FaChartBar className="mr-2 text-primary" />
            Análise de Mercado Imobiliário no DF
          </h1>
          
          {loading ? (
            <div className="bg-white rounded-lg shadow-md p-8 text-center">
              <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-primary mb-4"></div>
              <p className="text-gray-600">Carregando dados do mercado imobiliário...</p>
            </div>
          ) : error ? (
            <div className="bg-white rounded-lg shadow-md p-8 text-center text-red-600">
              <p>{error}</p>
              <button 
                onClick={() => searchProperties()}
                className="mt-4 px-4 py-2 bg-primary text-white rounded-md hover:bg-primary-dark"
              >
                Tentar novamente
              </button>
            </div>
          ) : (
            <div>
              {/* Tabs de navegação */}
              <div className="bg-white rounded-lg shadow-md mb-6">
                <div className="flex overflow-x-auto">
                  <button
                    onClick={() => setActiveTab('price')}
                    className={`px-4 py-3 font-medium text-sm flex items-center whitespace-nowrap ${
                      activeTab === 'price' 
                        ? 'text-primary border-b-2 border-primary' 
                        : 'text-gray-600 hover:text-primary'
                    }`}
                  >
                    <FaMoneyBillWave className="mr-2" />
                    Preço por Localização
                  </button>
                  <button
                    onClick={() => setActiveTab('bedrooms')}
                    className={`px-4 py-3 font-medium text-sm flex items-center whitespace-nowrap ${
                      activeTab === 'bedrooms' 
                        ? 'text-primary border-b-2 border-primary' 
                        : 'text-gray-600 hover:text-primary'
                    }`}
                  >
                    <FaBed className="mr-2" />
                    Distribuição por Quartos
                  </button>
                  <button
                    onClick={() => setActiveTab('area')}
                    className={`px-4 py-3 font-medium text-sm flex items-center whitespace-nowrap ${
                      activeTab === 'area' 
                        ? 'text-primary border-b-2 border-primary' 
                        : 'text-gray-600 hover:text-primary'
                    }`}
                  >
                    <FaBuilding className="mr-2" />
                    Área vs. Preço
                  </button>
                  <button
                    onClick={() => setActiveTab('ranges')}
                    className={`px-4 py-3 font-medium text-sm flex items-center whitespace-nowrap ${
                      activeTab === 'ranges' 
                        ? 'text-primary border-b-2 border-primary' 
                        : 'text-gray-600 hover:text-primary'
                    }`}
                  >
                    <FaMapMarkerAlt className="mr-2" />
                    Faixas de Preço
                  </button>
                </div>
              </div>
              
              {/* Conteúdo dos gráficos */}
              <div className="bg-white rounded-lg shadow-md p-6">
                {activeTab === 'price' && (
                  <div>
                    <h2 className="text-xl font-semibold mb-4">Preço Médio de Aluguel por Localização</h2>
                    <p className="text-gray-600 mb-6">
                      Este gráfico mostra o preço médio de aluguel em diferentes localizações do DF, 
                      permitindo identificar as áreas mais valorizadas e as mais acessíveis.
                    </p>
                    
                    <div className="h-96">
                      <Bar
                        options={barChartOptions}
                        data={{
                          labels: priceByLocation.labels,
                          datasets: [
                            {
                              label: 'Preço Médio (R$)',
                              data: priceByLocation.data,
                              backgroundColor: '#3B82F6', // Azul
                            },
                          ],
                        }}
                      />
                    </div>
                    
                    <div className="mt-6">
                      <h3 className="font-semibold mb-2">Insights:</h3>
                      <ul className="list-disc pl-5 text-gray-700 space-y-1">
                        <li>As regiões com aluguéis mais caros são geralmente as mais próximas do centro de Brasília.</li>
                        <li>Áreas como Lago Norte e Sudoeste apresentam os valores mais elevados.</li>
                        <li>Regiões como Taguatinga e Guará oferecem opções mais acessíveis.</li>
                      </ul>
                    </div>
                  </div>
                )}
                
                {activeTab === 'bedrooms' && (
                  <div>
                    <h2 className="text-xl font-semibold mb-4">Distribuição de Imóveis por Número de Quartos</h2>
                    <p className="text-gray-600 mb-6">
                      Este gráfico mostra a proporção de imóveis disponíveis para aluguel de acordo com o número de quartos,
                      ajudando a identificar a oferta mais comum no mercado.
                    </p>
                    
                    <div className="h-80 flex justify-center">
                      <div style={{ maxWidth: '500px' }}>
                        <Pie
                          options={pieChartOptions}
                          data={{
                            labels: bedroomsDistribution.labels,
                            datasets: [
                              {
                                label: 'Quantidade de Imóveis',
                                data: bedroomsDistribution.data,
                                backgroundColor: [
                                  '#3B82F6', // Azul
                                  '#F97316', // Laranja
                                  '#10B981', // Verde
                                  '#8B5CF6', // Roxo
                                  '#EC4899', // Rosa
                                ],
                              },
                            ],
                          }}
                        />
                      </div>
                    </div>
                    
                    <div className="mt-6">
                      <h3 className="font-semibold mb-2">Insights:</h3>
                      <ul className="list-disc pl-5 text-gray-700 space-y-1">
                        <li>Apartamentos de 2 e 3 quartos são os mais comuns no mercado de aluguel do DF.</li>
                        <li>Imóveis com 1 quarto são mais frequentes em áreas centrais e próximas a universidades.</li>
                        <li>Apartamentos com mais de 3 quartos são menos comuns e geralmente mais caros.</li>
                      </ul>
                    </div>
                  </div>
                )}
                
                {activeTab === 'area' && (
                  <div>
                    <h2 className="text-xl font-semibold mb-4">Relação entre Área e Preço</h2>
                    <p className="text-gray-600 mb-6">
                      Este gráfico mostra a correlação entre a área do imóvel e seu preço de aluguel,
                      permitindo analisar se imóveis maiores necessariamente significam aluguéis mais caros.
                    </p>
                    
                    <div className="h-80">
                      <Line
                        options={scatterChartOptions}
                        data={{
                          labels: areaPriceRelation.areas,
                          datasets: [
                            {
                              label: 'Preço (R$)',
                              data: areaPriceRelation.prices,
                              borderColor: '#F97316', // Laranja
                              backgroundColor: 'rgba(249, 115, 22, 0.5)',
                              tension: 0.1,
                            },
                          ],
                        }}
                      />
                    </div>
                    
                    <div className="mt-6">
                      <h3 className="font-semibold mb-2">Insights:</h3>
                      <ul className="list-disc pl-5 text-gray-700 space-y-1">
                        <li>Existe uma correlação positiva entre a área do imóvel e o preço do aluguel.</li>
                        <li>No entanto, a localização pode influenciar mais o preço do que a área em alguns casos.</li>
                        <li>Imóveis com áreas similares podem ter preços muito diferentes dependendo de outros fatores como comodidades e estado de conservação.</li>
                      </ul>
                    </div>
                  </div>
                )}
                
                {activeTab === 'ranges' && (
                  <div>
                    <h2 className="text-xl font-semibold mb-4">Distribuição de Imóveis por Faixa de Preço</h2>
                    <p className="text-gray-600 mb-6">
                      Este gráfico mostra a quantidade de imóveis disponíveis em cada faixa de preço,
                      ajudando a identificar as faixas com maior oferta no mercado.
                    </p>
                    
                    <div className="h-80">
                      <Bar
                        options={priceRangeOptions}
                        data={{
                          labels: priceRangeDistribution.labels,
                          datasets: [
                            {
                              label: 'Quantidade de Imóveis',
                              data: priceRangeDistribution.data,
                              backgroundColor: '#10B981', // Verde
                            },
                          ],
                        }}
                      />
                    </div>
                    
                    <div className="mt-6">
                      <h3 className="font-semibold mb-2">Insights:</h3>
                      <ul className="list-disc pl-5 text-gray-700 space-y-1">
                        <li>A maior parte dos imóveis para aluguel no DF está na faixa de R$ 1.500 a R$ 3.500.</li>
                        <li>Imóveis com aluguel abaixo de R$ 1.500 são mais raros e geralmente menores ou em regiões mais afastadas.</li>
                        <li>Imóveis com aluguel acima de R$ 5.000 representam o segmento premium do mercado, geralmente em localizações nobres.</li>
                      </ul>
                    </div>
                  </div>
                )}
              </div>
              
              {/* Resumo do mercado */}
              <div className="bg-white rounded-lg shadow-md p-6 mt-6">
                <h2 className="text-xl font-semibold mb-4">Resumo do Mercado Imobiliário no DF</h2>
                <p className="text-gray-700 mb-4">
                  Com base nos dados analisados, o mercado de aluguel no Distrito Federal apresenta características distintas
                  dependendo da região. As áreas mais valorizadas como Lago Norte, Sudoeste e Asa Norte têm os aluguéis mais caros,
                  enquanto regiões como Taguatinga, Guará e Ceilândia oferecem opções mais acessíveis.
                </p>
                <p className="text-gray-700 mb-4">
                  A maioria dos imóveis disponíveis possui 2 ou 3 quartos, sendo esta a configuração mais comum no mercado.
                  Existe uma correlação clara entre a área do imóvel e seu preço, mas outros fatores como localização,
                  comodidades e estado de conservação também influenciam significativamente o valor do aluguel.
                </p>
                <p className="text-gray-700">
                  Para encontrar as melhores oportunidades, recomenda-se comparar imóveis de características similares
                  em diferentes regiões e utilizar os filtros avançados de busca para refinar os resultados de acordo
                  com suas necessidades específicas.
                </p>
              </div>
            </div>
          )}
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default MarketInsightsPage;
