import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { FaArrowLeft, FaRuler, FaBed, FaBath, FaCar, FaDog, FaBuilding, FaStore, FaMoneyBillWave, FaCheck, FaTimes } from 'react-icons/fa';
import { getPropertyDetails } from '../services/propertyService';

const ComparisonPage = () => {
  const { ids } = useParams(); // Formato esperado: "id1,id2,id3"
  const navigate = useNavigate();
  
  const [properties, setProperties] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  useEffect(() => {
    const fetchProperties = async () => {
      try {
        setLoading(true);
        setError(null);
        
        if (!ids) {
          setError('Nenhum imóvel selecionado para comparação');
          setLoading(false);
          return;
        }
        
        const propertyIds = ids.split(',');
        
        if (propertyIds.length < 2) {
          setError('Selecione pelo menos 2 imóveis para comparar');
          setLoading(false);
          return;
        }
        
        // Buscar detalhes de cada imóvel
        const propertiesPromises = propertyIds.map(id => getPropertyDetails(id));
        const propertiesData = await Promise.all(propertiesPromises);
        
        // Filtrar possíveis nulos (imóveis que não existem)
        const validProperties = propertiesData.filter(Boolean);
        
        if (validProperties.length < 2) {
          setError('Não foi possível encontrar imóveis suficientes para comparação');
          setLoading(false);
          return;
        }
        
        setProperties(validProperties);
      } catch (error) {
        console.error('Erro ao carregar imóveis para comparação:', error);
        setError('Ocorreu um erro ao carregar os imóveis para comparação');
      } finally {
        setLoading(false);
      }
    };
    
    fetchProperties();
  }, [ids]);
  
  // Função para destacar o melhor valor em uma categoria
  const highlightBest = (values, category) => {
    if (!values || values.length < 2) return Array(values?.length).fill(false);
    
    const highlights = Array(values.length).fill(false);
    
    switch (category) {
      case 'price':
        // Menor preço é melhor
        const minPrice = Math.min(...values);
        values.forEach((value, index) => {
          if (value === minPrice) highlights[index] = true;
        });
        break;
      case 'area':
      case 'bedrooms':
      case 'bathrooms':
      case 'garage':
        // Maior valor é melhor
        const maxValue = Math.max(...values);
        values.forEach((value, index) => {
          if (value === maxValue) highlights[index] = true;
        });
        break;
      default:
        break;
    }
    
    return highlights;
  };
  
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow bg-gray-100 py-8">
        <div className="container-custom">
          {/* Cabeçalho */}
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-2xl font-bold text-gray-800">
              Comparação de Imóveis
            </h1>
            <button
              onClick={() => navigate(-1)}
              className="flex items-center text-primary hover:text-primary-dark"
            >
              <FaArrowLeft className="mr-1" /> Voltar
            </button>
          </div>
          
          {loading ? (
            <div className="bg-white rounded-lg shadow-md p-8 text-center">
              <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-primary mb-4"></div>
              <p className="text-gray-600">Carregando imóveis para comparação...</p>
            </div>
          ) : error ? (
            <div className="bg-white rounded-lg shadow-md p-8 text-center">
              <p className="text-red-600 mb-4">{error}</p>
              <Link 
                to="/buscar"
                className="px-4 py-2 bg-primary text-white rounded-md hover:bg-primary-dark"
              >
                Buscar Imóveis
              </Link>
            </div>
          ) : (
            <div className="bg-white rounded-lg shadow-md overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="bg-gray-50">
                    <th className="p-4 text-left text-gray-600 font-semibold w-1/4">Características</th>
                    {properties.map((property, index) => (
                      <th key={index} className="p-4 text-center">
                        <div className="mb-2">
                          <img 
                            src={property.images[0]} 
                            alt={property.title}
                            className="w-full h-32 object-cover rounded-md"
                          />
                        </div>
                        <h3 className="text-lg font-semibold text-gray-800">{property.title}</h3>
                        <p className="text-primary font-bold">R$ {property.price.toLocaleString('pt-BR')}</p>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {/* Localização */}
                  <tr className="border-t border-gray-200">
                    <td className="p-4 text-gray-700 font-medium">Localização</td>
                    {properties.map((property, index) => (
                      <td key={index} className="p-4 text-center text-gray-700">
                        {property.address}, {property.city}
                      </td>
                    ))}
                  </tr>
                  
                  {/* Preço */}
                  <tr className="border-t border-gray-200 bg-gray-50">
                    <td className="p-4 text-gray-700 font-medium">Preço</td>
                    {properties.map((property, index) => {
                      const priceHighlights = highlightBest(properties.map(p => p.price), 'price');
                      return (
                        <td 
                          key={index} 
                          className={`p-4 text-center font-bold ${priceHighlights[index] ? 'text-green-600' : 'text-gray-700'}`}
                        >
                          R$ {property.price.toLocaleString('pt-BR')}
                          {priceHighlights[index] && <span className="ml-2 text-xs bg-green-100 text-green-800 px-2 py-1 rounded">Melhor preço</span>}
                        </td>
                      );
                    })}
                  </tr>
                  
                  {/* Área */}
                  <tr className="border-t border-gray-200">
                    <td className="p-4 text-gray-700 font-medium">Área</td>
                    {properties.map((property, index) => {
                      const areaHighlights = highlightBest(properties.map(p => p.area), 'area');
                      return (
                        <td 
                          key={index} 
                          className={`p-4 text-center ${areaHighlights[index] ? 'text-green-600 font-bold' : 'text-gray-700'}`}
                        >
                          {property.area} m²
                          {areaHighlights[index] && <span className="ml-2 text-xs bg-green-100 text-green-800 px-2 py-1 rounded">Maior área</span>}
                        </td>
                      );
                    })}
                  </tr>
                  
                  {/* Quartos */}
                  <tr className="border-t border-gray-200 bg-gray-50">
                    <td className="p-4 text-gray-700 font-medium">Quartos</td>
                    {properties.map((property, index) => {
                      const bedroomsHighlights = highlightBest(properties.map(p => p.bedrooms), 'bedrooms');
                      return (
                        <td 
                          key={index} 
                          className={`p-4 text-center ${bedroomsHighlights[index] ? 'text-green-600 font-bold' : 'text-gray-700'}`}
                        >
                          {property.bedrooms}
                          {bedroomsHighlights[index] && property.bedrooms > 1 && <span className="ml-2 text-xs bg-green-100 text-green-800 px-2 py-1 rounded">Mais quartos</span>}
                        </td>
                      );
                    })}
                  </tr>
                  
                  {/* Banheiros */}
                  <tr className="border-t border-gray-200">
                    <td className="p-4 text-gray-700 font-medium">Banheiros</td>
                    {properties.map((property, index) => {
                      const bathroomsHighlights = highlightBest(properties.map(p => p.bathrooms), 'bathrooms');
                      return (
                        <td 
                          key={index} 
                          className={`p-4 text-center ${bathroomsHighlights[index] ? 'text-green-600 font-bold' : 'text-gray-700'}`}
                        >
                          {property.bathrooms}
                          {bathroomsHighlights[index] && property.bathrooms > 1 && <span className="ml-2 text-xs bg-green-100 text-green-800 px-2 py-1 rounded">Mais banheiros</span>}
                        </td>
                      );
                    })}
                  </tr>
                  
                  {/* Garagem */}
                  <tr className="border-t border-gray-200 bg-gray-50">
                    <td className="p-4 text-gray-700 font-medium">Vagas de Garagem</td>
                    {properties.map((property, index) => {
                      const garageHighlights = highlightBest(properties.map(p => p.garage), 'garage');
                      return (
                        <td 
                          key={index} 
                          className={`p-4 text-center ${garageHighlights[index] ? 'text-green-600 font-bold' : 'text-gray-700'}`}
                        >
                          {property.garage}
                          {garageHighlights[index] && property.garage > 1 && <span className="ml-2 text-xs bg-green-100 text-green-800 px-2 py-1 rounded">Mais vagas</span>}
                        </td>
                      );
                    })}
                  </tr>
                  
                  {/* Andar */}
                  <tr className="border-t border-gray-200">
                    <td className="p-4 text-gray-700 font-medium">Andar</td>
                    {properties.map((property, index) => (
                      <td key={index} className="p-4 text-center text-gray-700">
                        {property.floor === 0 ? 'Térreo' : `${property.floor}º andar`}
                      </td>
                    ))}
                  </tr>
                  
                  {/* Aceita Pets */}
                  <tr className="border-t border-gray-200 bg-gray-50">
                    <td className="p-4 text-gray-700 font-medium">Aceita Pets</td>
                    {properties.map((property, index) => (
                      <td key={index} className="p-4 text-center">
                        {property.allowsPets ? (
                          <span className="text-green-600 flex items-center justify-center">
                            <FaCheck className="mr-1" /> Sim
                          </span>
                        ) : (
                          <span className="text-red-600 flex items-center justify-center">
                            <FaTimes className="mr-1" /> Não
                          </span>
                        )}
                      </td>
                    ))}
                  </tr>
                  
                  {/* Comodidades */}
                  <tr className="border-t border-gray-200">
                    <td className="p-4 text-gray-700 font-medium">Comodidades</td>
                    {properties.map((property, index) => (
                      <td key={index} className="p-4 text-center">
                        <ul className="space-y-1">
                          {property.amenities.map((amenity, i) => {
                            let amenityName = '';
                            let icon = null;
                            
                            switch (amenity) {
                              case 'pool':
                                amenityName = 'Piscina';
                                icon = '🏊';
                                break;
                              case 'gym':
                                amenityName = 'Academia';
                                icon = '🏋️';
                                break;
                              case 'bbq':
                                amenityName = 'Churrasqueira';
                                icon = '🔥';
                                break;
                              case 'security':
                                amenityName = 'Segurança 24h';
                                icon = '🛡️';
                                break;
                              case 'party_room':
                                amenityName = 'Salão de Festas';
                                icon = '🥂';
                                break;
                              case 'playground':
                                amenityName = 'Playground';
                                icon = '👶';
                                break;
                              default:
                                amenityName = amenity;
                            }
                            
                            return (
                              <li key={i} className="text-gray-700">
                                <span className="mr-1">{icon}</span> {amenityName}
                              </li>
                            );
                          })}
                          
                          {property.amenities.length === 0 && (
                            <li className="text-gray-500">Nenhuma comodidade listada</li>
                          )}
                        </ul>
                      </td>
                    ))}
                  </tr>
                  
                  {/* Supermercados Próximos */}
                  <tr className="border-t border-gray-200 bg-gray-50">
                    <td className="p-4 text-gray-700 font-medium">Supermercados Próximos</td>
                    {properties.map((property, index) => (
                      <td key={index} className="p-4 text-center">
                        <ul className="space-y-1">
                          {property.nearbyMarkets && property.nearbyMarkets.map((market, i) => (
                            <li key={i} className="text-gray-700">
                              {market.name} - {market.distance}
                            </li>
                          ))}
                          
                          {(!property.nearbyMarkets || property.nearbyMarkets.length === 0) && (
                            <li className="text-gray-500">Nenhum supermercado listado</li>
                          )}
                        </ul>
                      </td>
                    ))}
                  </tr>
                  
                  {/* Botões de ação */}
                  <tr className="border-t border-gray-200">
                    <td className="p-4"></td>
                    {properties.map((property, index) => (
                      <td key={index} className="p-4 text-center">
                        <Link 
                          to={`/imovel/${property.id}`}
                          className="block w-full py-2 bg-primary hover:bg-primary-dark text-white rounded transition-colors"
                        >
                          Ver Detalhes
                        </Link>
                      </td>
                    ))}
                  </tr>
                </tbody>
              </table>
            </div>
          )}
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default ComparisonPage;
