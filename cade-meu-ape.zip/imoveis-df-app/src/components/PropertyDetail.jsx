import React, { useState } from 'react';
import { FaMapMarkerAlt, FaRuler, FaBed, FaBath, FaCar, FaDog, FaCalendarAlt, FaHeart, FaShare, FaExternalLinkAlt } from 'react-icons/fa';

const PropertyDetail = ({ property }) => {
  // Propriedade de exemplo para desenvolvimento
  const sampleProperty = {
    id: 1,
    title: 'Apartamento Moderno em Águas Claras',
    description: 'Lindo apartamento com acabamento de alto padrão, localizado em área nobre de Águas Claras. Próximo a estação de metrô, shopping, supermercados e escolas. Condomínio com infraestrutura completa incluindo piscina, academia, salão de festas e playground.',
    price: 2500,
    address: 'Rua das Araras, Águas Claras',
    city: 'Brasília',
    area: 75,
    bedrooms: 2,
    bathrooms: 1,
    garage: 1,
    floor: 5,
    allowsPets: true,
    amenities: ['pool', 'gym', 'bbq', 'security'],
    nearbyMarkets: [
      { name: 'Pão de Açúcar', distance: '300m' },
      { name: 'Extra', distance: '1.2km' }
    ],
    publishedDate: '2025-04-15',
    images: [
      'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80',
      'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80',
      'https://images.unsplash.com/photo-1560185007-cde436f6a4d0?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80',
      'https://images.unsplash.com/photo-1560185008-b033106af5c3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80'
    ],
    isFavorite: false,
    source: 'DF Imóveis',
    sourceUrl: 'https://www.dfimoveis.com.br'
  };

  // Usar a propriedade passada ou a amostra para desenvolvimento
  const propertyData = property || sampleProperty;
  
  // Estado para controlar a imagem principal
  const [mainImageIndex, setMainImageIndex] = useState(0);
  
  // Tradução das comodidades
  const amenitiesTranslation = {
    pool: { label: 'Piscina', icon: <FaSwimmingPool className="mr-1" /> },
    gym: { label: 'Academia', icon: <FaDumbbell className="mr-1" /> },
    playground: { label: 'Playground', icon: <FaChild className="mr-1" /> },
    bbq: { label: 'Churrasqueira', icon: <FaFireAlt className="mr-1" /> },
    security: { label: 'Segurança 24h', icon: <FaShieldAlt className="mr-1" /> },
    party_room: { label: 'Salão de Festas', icon: <FaGlassCheers className="mr-1" /> }
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      {/* Galeria de imagens */}
      <div className="relative">
        <div className="h-96 overflow-hidden">
          <img 
            src={propertyData.images[mainImageIndex]} 
            alt={propertyData.title}
            className="w-full h-full object-cover"
          />
        </div>
        
        {/* Miniaturas */}
        <div className="absolute bottom-4 left-0 right-0 flex justify-center">
          <div className="flex space-x-2 bg-black/50 p-2 rounded-lg">
            {propertyData.images.map((image, index) => (
              <button 
                key={index}
                onClick={() => setMainImageIndex(index)}
                className={`w-16 h-12 overflow-hidden rounded ${
                  index === mainImageIndex ? 'ring-2 ring-secondary' : 'opacity-70'
                }`}
              >
                <img 
                  src={image} 
                  alt={`Imagem ${index + 1}`}
                  className="w-full h-full object-cover"
                />
              </button>
            ))}
          </div>
        </div>
      </div>
      
      {/* Informações principais */}
      <div className="p-6">
        <div className="flex justify-between items-start mb-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-800">{propertyData.title}</h1>
            <p className="text-gray-600 flex items-center mt-1">
              <FaMapMarkerAlt className="mr-1 text-primary" />
              {propertyData.address}, {propertyData.city}
            </p>
          </div>
          <div className="text-right">
            <p className="text-3xl font-bold text-secondary">R$ {propertyData.price.toLocaleString('pt-BR')}</p>
            <p className="text-gray-500 text-sm">Aluguel mensal</p>
          </div>
        </div>
        
        {/* Ações */}
        <div className="flex space-x-2 mb-6">
          <button className={`flex items-center px-4 py-2 rounded-md ${
            propertyData.isFavorite 
              ? 'bg-secondary text-white' 
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
          }`}>
            <FaHeart className="mr-2" />
            {propertyData.isFavorite ? 'Favoritado' : 'Favoritar'}
          </button>
          <button className="flex items-center px-4 py-2 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200">
            <FaShare className="mr-2" />
            Compartilhar
          </button>
          <a 
            href={propertyData.sourceUrl} 
            target="_blank" 
            rel="noopener noreferrer"
            className="flex items-center px-4 py-2 bg-primary text-white rounded-md hover:bg-primary-dark ml-auto"
          >
            <FaExternalLinkAlt className="mr-2" />
            Ver no {propertyData.source}
          </a>
        </div>
        
        {/* Características */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6 border-t border-b border-gray-200 py-4">
          <div className="flex flex-col items-center">
            <FaRuler className="text-primary text-xl mb-1" />
            <span className="font-semibold">{propertyData.area} m²</span>
            <span className="text-sm text-gray-500">Área</span>
          </div>
          <div className="flex flex-col items-center">
            <FaBed className="text-primary text-xl mb-1" />
            <span className="font-semibold">{propertyData.bedrooms}</span>
            <span className="text-sm text-gray-500">Quartos</span>
          </div>
          <div className="flex flex-col items-center">
            <FaBath className="text-primary text-xl mb-1" />
            <span className="font-semibold">{propertyData.bathrooms}</span>
            <span className="text-sm text-gray-500">Banheiros</span>
          </div>
          <div className="flex flex-col items-center">
            <FaCar className="text-primary text-xl mb-1" />
            <span className="font-semibold">{propertyData.garage}</span>
            <span className="text-sm text-gray-500">Vagas</span>
          </div>
        </div>
        
        {/* Descrição */}
        <div className="mb-6">
          <h2 className="text-xl font-semibold text-gray-800 mb-2">Descrição</h2>
          <p className="text-gray-700">{propertyData.description}</p>
        </div>
        
        {/* Informações adicionais */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <div>
            <h2 className="text-xl font-semibold text-gray-800 mb-2">Detalhes</h2>
            <ul className="space-y-2">
              <li className="flex items-center text-gray-700">
                <FaRegBuilding className="mr-2 text-primary" />
                <span>Andar: {propertyData.floor}º</span>
              </li>
              <li className="flex items-center text-gray-700">
                <FaDog className="mr-2 text-primary" />
                <span>{propertyData.allowsPets ? 'Aceita pets' : 'Não aceita pets'}</span>
              </li>
              <li className="flex items-center text-gray-700">
                <FaCalendarAlt className="mr-2 text-primary" />
                <span>Publicado em: {new Date(propertyData.publishedDate).toLocaleDateString('pt-BR')}</span>
              </li>
            </ul>
          </div>
          
          <div>
            <h2 className="text-xl font-semibold text-gray-800 mb-2">Comodidades</h2>
            <div className="grid grid-cols-2 gap-2">
              {propertyData.amenities.map((amenity) => (
                <div key={amenity} className="flex items-center text-gray-700">
                  {amenitiesTranslation[amenity]?.icon}
                  <span>{amenitiesTranslation[amenity]?.label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
        
        {/* Supermercados próximos */}
        {propertyData.nearbyMarkets && propertyData.nearbyMarkets.length > 0 && (
          <div className="mb-6">
            <h2 className="text-xl font-semibold text-gray-800 mb-2">Supermercados Próximos</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {propertyData.nearbyMarkets.map((market, index) => (
                <div key={index} className="flex items-center text-gray-700">
                  <FaStore className="mr-2 text-primary" />
                  <span>{market.name} - {market.distance}</span>
                </div>
              ))}
            </div>
          </div>
        )}
        
        {/* Mapa - Placeholder */}
        <div className="mb-6">
          <h2 className="text-xl font-semibold text-gray-800 mb-2">Localização</h2>
          <div className="h-64 bg-gray-200 rounded-lg flex items-center justify-center">
            <p className="text-gray-500">Mapa será carregado aqui</p>
          </div>
        </div>
        
        {/* Contato */}
        <div className="bg-gray-50 p-4 rounded-lg">
          <h2 className="text-xl font-semibold text-gray-800 mb-2">Interessado neste imóvel?</h2>
          <p className="text-gray-700 mb-4">Entre em contato para agendar uma visita ou obter mais informações.</p>
          <button className="w-full py-3 bg-secondary hover:bg-secondary-dark text-white rounded-md transition-colors">
            Entrar em Contato
          </button>
        </div>
      </div>
    </div>
  );
};

// Importações adicionais para os ícones
const FaSwimmingPool = (props) => <span {...props}>🏊</span>;
const FaDumbbell = (props) => <span {...props}>🏋️</span>;
const FaChild = (props) => <span {...props}>👶</span>;
const FaFireAlt = (props) => <span {...props}>🔥</span>;
const FaShieldAlt = (props) => <span {...props}>🛡️</span>;
const FaGlassCheers = (props) => <span {...props}>🥂</span>;
const FaRegBuilding = (props) => <span {...props}>🏢</span>;

export default PropertyDetail;
