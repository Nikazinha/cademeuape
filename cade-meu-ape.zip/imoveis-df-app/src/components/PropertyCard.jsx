import React from 'react';
import { FaBuilding, FaMapMarkerAlt, FaBed, FaBath, FaCar, FaRuler, FaHeart } from 'react-icons/fa';

const PropertyCard = ({ property }) => {
  // Propriedade de exemplo para desenvolvimento
  const sampleProperty = {
    id: 1,
    title: 'Apartamento Moderno em Águas Claras',
    price: 2500,
    address: 'Rua das Araras, Águas Claras',
    area: 75,
    bedrooms: 2,
    bathrooms: 1,
    garage: 1,
    imageUrl: 'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80',
    isFavorite: false
  };

  // Usar a propriedade passada ou a amostra para desenvolvimento
  const propertyData = property || sampleProperty;

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform hover:shadow-lg hover:-translate-y-1">
      {/* Imagem do imóvel */}
      <div className="relative h-48 overflow-hidden">
        <img 
          src={propertyData.imageUrl} 
          alt={propertyData.title}
          className="w-full h-full object-cover"
        />
        <button 
          className={`absolute top-2 right-2 p-2 rounded-full ${
            propertyData.isFavorite ? 'bg-secondary text-white' : 'bg-white text-gray-500'
          }`}
          aria-label={propertyData.isFavorite ? "Remover dos favoritos" : "Adicionar aos favoritos"}
        >
          <FaHeart />
        </button>
      </div>
      
      {/* Informações do imóvel */}
      <div className="p-4">
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-lg font-semibold text-gray-800 line-clamp-1">{propertyData.title}</h3>
          <p className="text-secondary font-bold">R$ {propertyData.price.toLocaleString('pt-BR')}</p>
        </div>
        
        <div className="flex items-center text-gray-600 mb-3">
          <FaMapMarkerAlt className="mr-1 text-gray-400" />
          <p className="text-sm line-clamp-1">{propertyData.address}</p>
        </div>
        
        {/* Características do imóvel */}
        <div className="grid grid-cols-4 gap-2 text-sm text-gray-600">
          <div className="flex flex-col items-center">
            <div className="flex items-center">
              <FaRuler className="mr-1 text-primary" />
              <span>{propertyData.area}m²</span>
            </div>
            <span className="text-xs text-gray-500">Área</span>
          </div>
          
          <div className="flex flex-col items-center">
            <div className="flex items-center">
              <FaBed className="mr-1 text-primary" />
              <span>{propertyData.bedrooms}</span>
            </div>
            <span className="text-xs text-gray-500">Quartos</span>
          </div>
          
          <div className="flex flex-col items-center">
            <div className="flex items-center">
              <FaBath className="mr-1 text-primary" />
              <span>{propertyData.bathrooms}</span>
            </div>
            <span className="text-xs text-gray-500">Banheiros</span>
          </div>
          
          <div className="flex flex-col items-center">
            <div className="flex items-center">
              <FaCar className="mr-1 text-primary" />
              <span>{propertyData.garage}</span>
            </div>
            <span className="text-xs text-gray-500">Vagas</span>
          </div>
        </div>
      </div>
      
      {/* Botão de detalhes */}
      <div className="px-4 pb-4">
        <button className="w-full py-2 bg-primary hover:bg-primary-dark text-white rounded transition-colors">
          Ver Detalhes
        </button>
      </div>
    </div>
  );
};

export default PropertyCard;
