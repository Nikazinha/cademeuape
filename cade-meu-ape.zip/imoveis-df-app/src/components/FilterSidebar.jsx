import React, { useState } from 'react';
import { FaFilter, FaMapMarkerAlt, FaRuler, FaBed, FaBath, FaCar, FaDog, FaBuilding, FaStore, FaSwimmingPool, FaMoneyBillWave } from 'react-icons/fa';

const FilterSidebar = ({ onApplyFilters }) => {
  // Estados para os filtros
  const [location, setLocation] = useState('');
  const [minArea, setMinArea] = useState('');
  const [maxArea, setMaxArea] = useState('');
  const [bedrooms, setBedrooms] = useState('');
  const [bathrooms, setBathrooms] = useState('');
  const [hasGarage, setHasGarage] = useState(false);
  const [allowsPets, setAllowsPets] = useState(false);
  const [minPrice, setMinPrice] = useState('');
  const [maxPrice, setMaxPrice] = useState('');
  const [floor, setFloor] = useState('');
  const [amenities, setAmenities] = useState([]);
  const [nearbyMarkets, setNearbyMarkets] = useState(false);

  // Lista de cidades do DF
  const dfCities = [
    'Águas Claras', 'Brasília', 'Ceilândia', 'Gama', 'Guará', 
    'Lago Norte', 'Lago Sul', 'Noroeste', 'Núcleo Bandeirante', 
    'Paranoá', 'Park Way', 'Planaltina', 'Recanto das Emas', 
    'Riacho Fundo', 'Samambaia', 'Santa Maria', 'São Sebastião', 
    'Sobradinho', 'Sudoeste/Octogonal', 'Taguatinga'
  ];

  // Lista de comodidades
  const amenitiesList = [
    { id: 'pool', label: 'Piscina', icon: <FaSwimmingPool /> },
    { id: 'gym', label: 'Academia', icon: <FaBuilding /> },
    { id: 'playground', label: 'Playground', icon: <FaBuilding /> },
    { id: 'bbq', label: 'Churrasqueira', icon: <FaBuilding /> },
    { id: 'security', label: 'Segurança 24h', icon: <FaBuilding /> },
    { id: 'party_room', label: 'Salão de Festas', icon: <FaBuilding /> }
  ];

  // Manipulador de comodidades
  const handleAmenityToggle = (amenityId) => {
    if (amenities.includes(amenityId)) {
      setAmenities(amenities.filter(id => id !== amenityId));
    } else {
      setAmenities([...amenities, amenityId]);
    }
  };

  // Aplicar filtros
  const handleApplyFilters = () => {
    const filters = {
      location,
      area: { min: minArea, max: maxArea },
      bedrooms: bedrooms ? parseInt(bedrooms) : null,
      bathrooms: bathrooms ? parseInt(bathrooms) : null,
      hasGarage,
      allowsPets,
      price: { min: minPrice, max: maxPrice },
      floor: floor ? parseInt(floor) : null,
      amenities,
      nearbyMarkets
    };
    
    if (onApplyFilters) {
      onApplyFilters(filters);
    }
  };

  // Limpar filtros
  const handleClearFilters = () => {
    setLocation('');
    setMinArea('');
    setMaxArea('');
    setBedrooms('');
    setBathrooms('');
    setHasGarage(false);
    setAllowsPets(false);
    setMinPrice('');
    setMaxPrice('');
    setFloor('');
    setAmenities([]);
    setNearbyMarkets(false);
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-4">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold text-gray-800 flex items-center">
          <FaFilter className="mr-2 text-primary" />
          Filtros Avançados
        </h2>
        <button 
          onClick={handleClearFilters}
          className="text-sm text-primary hover:text-primary-dark"
        >
          Limpar Filtros
        </button>
      </div>

      <div className="space-y-4">
        {/* Localização */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            <FaMapMarkerAlt className="inline mr-1" /> Localização
          </label>
          <select
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            className="w-full p-2 border border-gray-300 rounded-md focus:ring-primary focus:border-primary"
          >
            <option value="">Todas as localidades</option>
            {dfCities.map((city) => (
              <option key={city} value={city}>{city}</option>
            ))}
          </select>
        </div>

        {/* Área */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            <FaRuler className="inline mr-1" /> Área (m²)
          </label>
          <div className="grid grid-cols-2 gap-2">
            <input
              type="number"
              placeholder="Mín"
              value={minArea}
              onChange={(e) => setMinArea(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded-md focus:ring-primary focus:border-primary"
            />
            <input
              type="number"
              placeholder="Máx"
              value={maxArea}
              onChange={(e) => setMaxArea(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded-md focus:ring-primary focus:border-primary"
            />
          </div>
        </div>

        {/* Quartos e Banheiros */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              <FaBed className="inline mr-1" /> Quartos
            </label>
            <select
              value={bedrooms}
              onChange={(e) => setBedrooms(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded-md focus:ring-primary focus:border-primary"
            >
              <option value="">Qualquer</option>
              <option value="1">1+</option>
              <option value="2">2+</option>
              <option value="3">3+</option>
              <option value="4">4+</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              <FaBath className="inline mr-1" /> Banheiros
            </label>
            <select
              value={bathrooms}
              onChange={(e) => setBathrooms(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded-md focus:ring-primary focus:border-primary"
            >
              <option value="">Qualquer</option>
              <option value="1">1+</option>
              <option value="2">2+</option>
              <option value="3">3+</option>
              <option value="4">4+</option>
            </select>
          </div>
        </div>

        {/* Preço */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            <FaMoneyBillWave className="inline mr-1" /> Preço do Aluguel (R$)
          </label>
          <div className="grid grid-cols-2 gap-2">
            <input
              type="number"
              placeholder="Mín"
              value={minPrice}
              onChange={(e) => setMinPrice(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded-md focus:ring-primary focus:border-primary"
            />
            <input
              type="number"
              placeholder="Máx"
              value={maxPrice}
              onChange={(e) => setMaxPrice(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded-md focus:ring-primary focus:border-primary"
            />
          </div>
        </div>

        {/* Andar */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            <FaBuilding className="inline mr-1" /> Andar
          </label>
          <select
            value={floor}
            onChange={(e) => setFloor(e.target.value)}
            className="w-full p-2 border border-gray-300 rounded-md focus:ring-primary focus:border-primary"
          >
            <option value="">Qualquer</option>
            <option value="0">Térreo</option>
            <option value="1">1º andar</option>
            <option value="2">2º andar ou acima</option>
            <option value="5">5º andar ou acima</option>
            <option value="10">10º andar ou acima</option>
          </select>
        </div>

        {/* Características adicionais */}
        <div>
          <p className="block text-sm font-medium text-gray-700 mb-2">Características</p>
          <div className="space-y-2">
            <label className="flex items-center">
              <input
                type="checkbox"
                checked={hasGarage}
                onChange={(e) => setHasGarage(e.target.checked)}
                className="h-4 w-4 text-primary focus:ring-primary border-gray-300 rounded"
              />
              <span className="ml-2 text-sm text-gray-700">
                <FaCar className="inline mr-1" /> Possui garagem
              </span>
            </label>
            <label className="flex items-center">
              <input
                type="checkbox"
                checked={allowsPets}
                onChange={(e) => setAllowsPets(e.target.checked)}
                className="h-4 w-4 text-primary focus:ring-primary border-gray-300 rounded"
              />
              <span className="ml-2 text-sm text-gray-700">
                <FaDog className="inline mr-1" /> Aceita pets
              </span>
            </label>
            <label className="flex items-center">
              <input
                type="checkbox"
                checked={nearbyMarkets}
                onChange={(e) => setNearbyMarkets(e.target.checked)}
                className="h-4 w-4 text-primary focus:ring-primary border-gray-300 rounded"
              />
              <span className="ml-2 text-sm text-gray-700">
                <FaStore className="inline mr-1" /> Supermercados próximos
              </span>
            </label>
          </div>
        </div>

        {/* Comodidades */}
        <div>
          <p className="block text-sm font-medium text-gray-700 mb-2">Comodidades</p>
          <div className="grid grid-cols-2 gap-2">
            {amenitiesList.map((amenity) => (
              <label key={amenity.id} className="flex items-center">
                <input
                  type="checkbox"
                  checked={amenities.includes(amenity.id)}
                  onChange={() => handleAmenityToggle(amenity.id)}
                  className="h-4 w-4 text-primary focus:ring-primary border-gray-300 rounded"
                />
                <span className="ml-2 text-sm text-gray-700">
                  {amenity.icon} {amenity.label}
                </span>
              </label>
            ))}
          </div>
        </div>

        {/* Botão de aplicar filtros */}
        <button
          onClick={handleApplyFilters}
          className="w-full py-2 bg-secondary hover:bg-secondary-dark text-white rounded-md transition-colors"
        >
          Aplicar Filtros
        </button>
      </div>
    </div>
  );
};

export default FilterSidebar;
