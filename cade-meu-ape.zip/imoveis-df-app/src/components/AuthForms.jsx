import React, { useState } from 'react';
import { FaUser, FaEnvelope, FaLock, FaEye, FaEyeSlash } from 'react-icons/fa';

const AuthForms = ({ formType = 'login' }) => {
  // Estados para formulário de login
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  
  // Estados adicionais para formulário de cadastro
  const [name, setName] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  
  // Estado para mensagens de erro/sucesso
  const [message, setMessage] = useState({ type: '', text: '' });
  
  // Manipulador de envio do formulário
  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Validação básica
    if (!email || !password) {
      setMessage({ type: 'error', text: 'Por favor, preencha todos os campos obrigatórios.' });
      return;
    }
    
    if (formType === 'register') {
      if (!name) {
        setMessage({ type: 'error', text: 'Por favor, informe seu nome.' });
        return;
      }
      
      if (password !== confirmPassword) {
        setMessage({ type: 'error', text: 'As senhas não coincidem.' });
        return;
      }
    }
    
    // Simulação de autenticação bem-sucedida
    setMessage({ 
      type: 'success', 
      text: formType === 'login' 
        ? 'Login realizado com sucesso!' 
        : 'Cadastro realizado com sucesso! Verifique seu e-mail para confirmar sua conta.'
    });
    
    // Aqui seria implementada a lógica real de autenticação
    console.log('Form submitted:', { email, password, name });
  };
  
  return (
    <div className="bg-white rounded-lg shadow-md p-6 max-w-md mx-auto">
      <h2 className="text-2xl font-bold text-center text-gray-800 mb-6">
        {formType === 'login' ? 'Entrar na sua conta' : 'Criar uma nova conta'}
      </h2>
      
      {/* Mensagem de erro ou sucesso */}
      {message.text && (
        <div className={`p-3 rounded mb-4 ${
          message.type === 'error' ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'
        }`}>
          {message.text}
        </div>
      )}
      
      <form onSubmit={handleSubmit}>
        {/* Campo de nome (apenas para cadastro) */}
        {formType === 'register' && (
          <div className="mb-4">
            <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
              Nome completo
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <FaUser className="text-gray-400" />
              </div>
              <input
                id="name"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="pl-10 w-full p-3 border border-gray-300 rounded-md focus:ring-primary focus:border-primary"
                placeholder="Digite seu nome completo"
              />
            </div>
          </div>
        )}
        
        {/* Campo de e-mail */}
        <div className="mb-4">
          <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
            E-mail
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <FaEnvelope className="text-gray-400" />
            </div>
            <input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="pl-10 w-full p-3 border border-gray-300 rounded-md focus:ring-primary focus:border-primary"
              placeholder="Digite seu e-mail"
            />
          </div>
        </div>
        
        {/* Campo de senha */}
        <div className="mb-4">
          <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">
            Senha
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <FaLock className="text-gray-400" />
            </div>
            <input
              id="password"
              type={showPassword ? "text" : "password"}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="pl-10 w-full p-3 border border-gray-300 rounded-md focus:ring-primary focus:border-primary"
              placeholder="Digite sua senha"
            />
            <button
              type="button"
              className="absolute inset-y-0 right-0 pr-3 flex items-center"
              onClick={() => setShowPassword(!showPassword)}
            >
              {showPassword ? <FaEyeSlash className="text-gray-400" /> : <FaEye className="text-gray-400" />}
            </button>
          </div>
        </div>
        
        {/* Campo de confirmação de senha (apenas para cadastro) */}
        {formType === 'register' && (
          <div className="mb-4">
            <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700 mb-1">
              Confirmar senha
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <FaLock className="text-gray-400" />
              </div>
              <input
                id="confirmPassword"
                type={showConfirmPassword ? "text" : "password"}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="pl-10 w-full p-3 border border-gray-300 rounded-md focus:ring-primary focus:border-primary"
                placeholder="Confirme sua senha"
              />
              <button
                type="button"
                className="absolute inset-y-0 right-0 pr-3 flex items-center"
                onClick={() => setShowConfirmPassword(!showConfirmPassword)}
              >
                {showConfirmPassword ? <FaEyeSlash className="text-gray-400" /> : <FaEye className="text-gray-400" />}
              </button>
            </div>
          </div>
        )}
        
        {/* Link para recuperação de senha (apenas para login) */}
        {formType === 'login' && (
          <div className="flex justify-end mb-4">
            <a href="/recuperar-senha" className="text-sm text-primary hover:text-primary-dark">
              Esqueceu sua senha?
            </a>
          </div>
        )}
        
        {/* Botão de envio */}
        <button
          type="submit"
          className="w-full bg-primary hover:bg-primary-dark text-white font-medium py-3 px-4 rounded-md transition-colors"
        >
          {formType === 'login' ? 'Entrar' : 'Cadastrar'}
        </button>
      </form>
      
      {/* Link para alternar entre login e cadastro */}
      <div className="mt-4 text-center">
        {formType === 'login' ? (
          <p className="text-gray-600">
            Não tem uma conta?{' '}
            <a href="/cadastrar" className="text-primary hover:text-primary-dark font-medium">
              Cadastre-se
            </a>
          </p>
        ) : (
          <p className="text-gray-600">
            Já tem uma conta?{' '}
            <a href="/entrar" className="text-primary hover:text-primary-dark font-medium">
              Faça login
            </a>
          </p>
        )}
      </div>
    </div>
  );
};

export default AuthForms;
