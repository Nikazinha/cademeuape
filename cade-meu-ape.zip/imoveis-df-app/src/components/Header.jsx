import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { FaSearch, FaUser, FaHeart, FaBars, FaTimes } from 'react-icons/fa';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false); // Simulação de estado de login

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <header className="bg-white shadow-md sticky top-0 z-50">
      <div className="container-custom py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center">
            <div className="text-2xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              ImóveisDF
            </div>
          </Link>

          {/* Menu para desktop */}
          <nav className="hidden md:flex items-center space-x-6">
            <Link to="/" className="text-gray-700 hover:text-primary transition-colors">
              Início
            </Link>
            <Link to="/buscar" className="text-gray-700 hover:text-primary transition-colors">
              Buscar Imóveis
            </Link>
            <Link to="/sobre" className="text-gray-700 hover:text-primary transition-colors">
              Sobre
            </Link>
            <Link to="/contato" className="text-gray-700 hover:text-primary transition-colors">
              Contato
            </Link>
          </nav>

          {/* Botões de ação para desktop */}
          <div className="hidden md:flex items-center space-x-4">
            {isLoggedIn ? (
              <>
                <Link to="/favoritos" className="text-gray-700 hover:text-primary transition-colors">
                  <FaHeart className="inline mr-1" /> Favoritos
                </Link>
                <Link to="/perfil" className="btn-primary">
                  <FaUser className="inline mr-1" /> Minha Conta
                </Link>
              </>
            ) : (
              <>
                <Link to="/entrar" className="text-primary hover:text-primary-dark transition-colors">
                  Entrar
                </Link>
                <Link to="/cadastrar" className="btn-primary">
                  Cadastrar
                </Link>
              </>
            )}
          </div>

          {/* Botão de menu para mobile */}
          <button
            className="md:hidden text-gray-700 focus:outline-none"
            onClick={toggleMenu}
          >
            {isMenuOpen ? <FaTimes size={24} /> : <FaBars size={24} />}
          </button>
        </div>

        {/* Menu mobile */}
        {isMenuOpen && (
          <div className="md:hidden mt-4 pb-4">
            <nav className="flex flex-col space-y-4">
              <Link
                to="/"
                className="text-gray-700 hover:text-primary transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                Início
              </Link>
              <Link
                to="/buscar"
                className="text-gray-700 hover:text-primary transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                Buscar Imóveis
              </Link>
              <Link
                to="/sobre"
                className="text-gray-700 hover:text-primary transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                Sobre
              </Link>
              <Link
                to="/contato"
                className="text-gray-700 hover:text-primary transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                Contato
              </Link>

              {isLoggedIn ? (
                <>
                  <Link
                    to="/favoritos"
                    className="text-gray-700 hover:text-primary transition-colors"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    <FaHeart className="inline mr-1" /> Favoritos
                  </Link>
                  <Link
                    to="/perfil"
                    className="btn-primary inline-block text-center"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    <FaUser className="inline mr-1" /> Minha Conta
                  </Link>
                </>
              ) : (
                <>
                  <Link
                    to="/entrar"
                    className="text-primary hover:text-primary-dark transition-colors"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    Entrar
                  </Link>
                  <Link
                    to="/cadastrar"
                    className="btn-primary inline-block text-center"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    Cadastrar
                  </Link>
                </>
              )}
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
