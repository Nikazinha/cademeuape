import React from 'react';
import { FaSort, FaSortAmountDown, FaSortAmountUp, FaThLarge, FaList } from 'react-icons/fa';

const SearchResults = ({ properties, viewMode, setViewMode, sortOption, setSortOption }) => {
  // Opções de ordenação
  const sortOptions = [
    { value: 'price_asc', label: 'Menor preço', icon: <FaSortAmountUp /> },
    { value: 'price_desc', label: 'Maior preço', icon: <FaSortAmountDown /> },
    { value: 'area_asc', label: 'Menor área', icon: <FaSortAmountUp /> },
    { value: 'area_desc', label: 'Maior área', icon: <FaSortAmountDown /> },
    { value: 'newest', label: 'Mais recentes', icon: <FaSort /> }
  ];

  return (
    <div className="bg-white rounded-lg shadow-md p-4">
      {/* Cabeçalho dos resultados */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-4 gap-2">
        <div>
          <h2 className="text-xl font-semibold text-gray-800">
            {properties.length} imóveis encontrados
          </h2>
        </div>
        
        <div className="flex flex-col md:flex-row gap-2 md:gap-4">
          {/* Seletor de ordenação */}
          <div className="flex items-center">
            <label htmlFor="sort" className="mr-2 text-sm text-gray-600">Ordenar por:</label>
            <select
              id="sort"
              value={sortOption}
              onChange={(e) => setSortOption(e.target.value)}
              className="p-2 border border-gray-300 rounded-md focus:ring-primary focus:border-primary text-sm"
            >
              {sortOptions.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </div>
          
          {/* Alternador de visualização */}
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-2 rounded-md ${
                viewMode === 'grid' 
                  ? 'bg-primary text-white' 
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
              aria-label="Visualização em grade"
            >
              <FaThLarge />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-2 rounded-md ${
                viewMode === 'list' 
                  ? 'bg-primary text-white' 
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
              aria-label="Visualização em lista"
            >
              <FaList />
            </button>
          </div>
        </div>
      </div>
      
      {/* Mensagem quando não há resultados */}
      {properties.length === 0 && (
        <div className="text-center py-8">
          <p className="text-gray-500 text-lg">Nenhum imóvel encontrado com os filtros selecionados.</p>
          <p className="text-gray-500">Tente ajustar seus filtros para ver mais resultados.</p>
        </div>
      )}
      
      {/* Conteúdo dos resultados - será preenchido pelos componentes filhos */}
      <div className={`mt-4 ${
        viewMode === 'grid' 
          ? 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4' 
          : 'space-y-4'
      }`}>
        {/* Os componentes PropertyCard ou PropertyListItem serão renderizados aqui */}
        {/* Este é apenas um placeholder para a estrutura */}
        {properties.map((property) => (
          <div key={property.id} className="bg-gray-100 p-4 rounded-md">
            {property.title} - R$ {property.price}
          </div>
        ))}
      </div>
      
      {/* Paginação */}
      {properties.length > 0 && (
        <div className="mt-6 flex justify-center">
          <nav className="flex items-center space-x-2">
            <button className="px-3 py-1 rounded-md bg-gray-100 text-gray-600 hover:bg-gray-200">
              Anterior
            </button>
            <button className="px-3 py-1 rounded-md bg-primary text-white">
              1
            </button>
            <button className="px-3 py-1 rounded-md bg-gray-100 text-gray-600 hover:bg-gray-200">
              2
            </button>
            <button className="px-3 py-1 rounded-md bg-gray-100 text-gray-600 hover:bg-gray-200">
              3
            </button>
            <span className="px-3 py-1">...</span>
            <button className="px-3 py-1 rounded-md bg-gray-100 text-gray-600 hover:bg-gray-200">
              10
            </button>
            <button className="px-3 py-1 rounded-md bg-gray-100 text-gray-600 hover:bg-gray-200">
              Próximo
            </button>
          </nav>
        </div>
      )}
    </div>
  );
};

export default SearchResults;
