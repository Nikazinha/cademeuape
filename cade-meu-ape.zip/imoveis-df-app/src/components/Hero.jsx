import React, { useState } from 'react';
import { FaSearch, FaMapMarkerAlt, FaBed, FaBath, FaCar, FaDog, FaBuilding, FaStore, FaMoneyBillWave } from 'react-icons/fa';

const Hero = () => {
  const [location, setLocation] = useState('');
  
  const handleSearch = (e) => {
    e.preventDefault();
    // Implementação futura: redirecionar para a página de busca com o filtro de localização
    console.log('Buscar em:', location);
  };

  return (
    <div className="relative bg-gradient-to-r from-primary to-primary-dark text-white">
      {/* Overlay de imagem com gradiente */}
      <div 
        className="absolute inset-0 bg-black opacity-50 z-0"
        style={{
          backgroundImage: 'url("https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80")',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          mixBlendMode: 'overlay'
        }}
      ></div>
      
      <div className="container-custom relative z-10 py-20 md:py-32">
        <div className="max-w-3xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">
            Encontre o Imóvel Perfeito para Alugar no DF
          </h1>
          <p className="text-xl mb-8 text-gray-100">
            Busca avançada com filtros personalizados para encontrar o lar dos seus sonhos no Distrito Federal
          </p>
          
          {/* Formulário de busca rápida */}
          <form onSubmit={handleSearch} className="bg-white p-4 rounded-lg shadow-lg flex flex-col md:flex-row">
            <div className="flex-grow mb-3 md:mb-0 md:mr-3">
              <div className="relative">
                <FaMapMarkerAlt className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  placeholder="Digite a cidade ou bairro no DF"
                  className="w-full pl-10 pr-4 py-3 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-primary"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                />
              </div>
            </div>
            <button 
              type="submit" 
              className="bg-secondary hover:bg-secondary-dark text-white py-3 px-6 rounded-md transition-colors flex items-center justify-center"
            >
              <FaSearch className="mr-2" />
              Buscar
            </button>
          </form>
          
          {/* Ícones de filtros populares */}
          <div className="mt-8 grid grid-cols-2 md:grid-cols-5 gap-4">
            <div className="flex flex-col items-center">
              <div className="bg-white/20 p-3 rounded-full mb-2">
                <FaMapMarkerAlt className="text-2xl" />
              </div>
              <span className="text-sm">Localização</span>
            </div>
            <div className="flex flex-col items-center">
              <div className="bg-white/20 p-3 rounded-full mb-2">
                <FaBed className="text-2xl" />
              </div>
              <span className="text-sm">Quartos</span>
            </div>
            <div className="flex flex-col items-center">
              <div className="bg-white/20 p-3 rounded-full mb-2">
                <FaBath className="text-2xl" />
              </div>
              <span className="text-sm">Banheiros</span>
            </div>
            <div className="flex flex-col items-center">
              <div className="bg-white/20 p-3 rounded-full mb-2">
                <FaCar className="text-2xl" />
              </div>
              <span className="text-sm">Garagem</span>
            </div>
            <div className="flex flex-col items-center">
              <div className="bg-white/20 p-3 rounded-full mb-2">
                <FaMoneyBillWave className="text-2xl" />
              </div>
              <span className="text-sm">Preço</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;
