import React, { useState, useEffect, createContext, useContext } from 'react';

// Criar o contexto de autenticação
const AuthContext = createContext();

// Hook personalizado para usar o contexto de autenticação
export const useAuth = () => useContext(AuthContext);

// Provedor de autenticação
export const AuthProvider = ({ children }) => {
  // Estado para armazenar o usuário atual
  const [currentUser, setCurrentUser] = useState(null);
  
  // Estado para controlar se a autenticação está sendo verificada
  const [loading, setLoading] = useState(true);
  
  // Efeito para verificar se há um usuário logado no localStorage
  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      setCurrentUser(JSON.parse(storedUser));
    }
    setLoading(false);
  }, []);
  
  // Função para registrar um novo usuário
  const register = async (name, email, password) => {
    try {
      // Em um ambiente real, esta seria uma chamada para uma API de autenticação
      // Aqui estamos simulando o registro
      
      // Verificar se o e-mail já está em uso
      const storedUsers = JSON.parse(localStorage.getItem('users') || '[]');
      const existingUser = storedUsers.find(user => user.email === email);
      
      if (existingUser) {
        throw new Error('Este e-mail já está em uso');
      }
      
      // Criar novo usuário
      const newUser = {
        id: Date.now().toString(),
        name,
        email,
        password, // Em um ambiente real, a senha seria hash
        createdAt: new Date().toISOString(),
        favorites: []
      };
      
      // Salvar no localStorage
      localStorage.setItem('users', JSON.stringify([...storedUsers, newUser]));
      
      // Definir usuário atual (sem a senha)
      const userWithoutPassword = { ...newUser };
      delete userWithoutPassword.password;
      
      setCurrentUser(userWithoutPassword);
      localStorage.setItem('user', JSON.stringify(userWithoutPassword));
      
      return { success: true };
    } catch (error) {
      return { success: false, error: error.message };
    }
  };
  
  // Função para fazer login
  const login = async (email, password) => {
    try {
      // Em um ambiente real, esta seria uma chamada para uma API de autenticação
      // Aqui estamos simulando o login
      
      // Buscar usuários do localStorage
      const storedUsers = JSON.parse(localStorage.getItem('users') || '[]');
      const user = storedUsers.find(user => user.email === email);
      
      if (!user) {
        throw new Error('E-mail ou senha incorretos');
      }
      
      if (user.password !== password) {
        throw new Error('E-mail ou senha incorretos');
      }
      
      // Definir usuário atual (sem a senha)
      const userWithoutPassword = { ...user };
      delete userWithoutPassword.password;
      
      setCurrentUser(userWithoutPassword);
      localStorage.setItem('user', JSON.stringify(userWithoutPassword));
      
      return { success: true };
    } catch (error) {
      return { success: false, error: error.message };
    }
  };
  
  // Função para fazer logout
  const logout = () => {
    setCurrentUser(null);
    localStorage.removeItem('user');
  };
  
  // Função para adicionar um imóvel aos favoritos
  const addToFavorites = (propertyId) => {
    if (!currentUser) return { success: false, error: 'Usuário não autenticado' };
    
    try {
      // Buscar usuários do localStorage
      const storedUsers = JSON.parse(localStorage.getItem('users') || '[]');
      const userIndex = storedUsers.findIndex(user => user.id === currentUser.id);
      
      if (userIndex === -1) {
        throw new Error('Usuário não encontrado');
      }
      
      // Verificar se o imóvel já está nos favoritos
      if (currentUser.favorites.includes(propertyId)) {
        return { success: true, message: 'Imóvel já está nos favoritos' };
      }
      
      // Adicionar aos favoritos
      const updatedFavorites = [...currentUser.favorites, propertyId];
      const updatedUser = { ...currentUser, favorites: updatedFavorites };
      
      // Atualizar usuário atual
      setCurrentUser(updatedUser);
      localStorage.setItem('user', JSON.stringify(updatedUser));
      
      // Atualizar no array de usuários
      storedUsers[userIndex] = { ...storedUsers[userIndex], favorites: updatedFavorites };
      localStorage.setItem('users', JSON.stringify(storedUsers));
      
      return { success: true };
    } catch (error) {
      return { success: false, error: error.message };
    }
  };
  
  // Função para remover um imóvel dos favoritos
  const removeFromFavorites = (propertyId) => {
    if (!currentUser) return { success: false, error: 'Usuário não autenticado' };
    
    try {
      // Buscar usuários do localStorage
      const storedUsers = JSON.parse(localStorage.getItem('users') || '[]');
      const userIndex = storedUsers.findIndex(user => user.id === currentUser.id);
      
      if (userIndex === -1) {
        throw new Error('Usuário não encontrado');
      }
      
      // Remover dos favoritos
      const updatedFavorites = currentUser.favorites.filter(id => id !== propertyId);
      const updatedUser = { ...currentUser, favorites: updatedFavorites };
      
      // Atualizar usuário atual
      setCurrentUser(updatedUser);
      localStorage.setItem('user', JSON.stringify(updatedUser));
      
      // Atualizar no array de usuários
      storedUsers[userIndex] = { ...storedUsers[userIndex], favorites: updatedFavorites };
      localStorage.setItem('users', JSON.stringify(storedUsers));
      
      return { success: true };
    } catch (error) {
      return { success: false, error: error.message };
    }
  };
  
  // Função para verificar se um imóvel está nos favoritos
  const isFavorite = (propertyId) => {
    return currentUser && currentUser.favorites.includes(propertyId);
  };
  
  // Função para obter todos os imóveis favoritos
  const getFavorites = async () => {
    if (!currentUser) return [];
    
    // Em um ambiente real, esta seria uma chamada para uma API
    // Aqui estamos apenas retornando os IDs dos favoritos
    return currentUser.favorites;
  };
  
  // Valor do contexto
  const value = {
    currentUser,
    loading,
    register,
    login,
    logout,
    addToFavorites,
    removeFromFavorites,
    isFavorite,
    getFavorites
  };
  
  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
};
